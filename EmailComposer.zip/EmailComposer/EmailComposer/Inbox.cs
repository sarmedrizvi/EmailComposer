﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using GemBox.Email;
using GemBox.Email.Imap;

namespace EmailComposer
{
    public partial class Inbox : UserControl
    {
        public Inbox()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            using (var pop = new ImapClient("pop.gmail.com"))
            {
                //  Connect and sign to POP server.
                pop.Connect();
                pop.Authenticate(EmailSend.UserName, EmailSend.Password);
                pop.SelectFolder("Inbox", true);
                // Read the number of currently available emails on the server.
                int? count= pop.SelectedFolder.Unseen;
             
                // Download and receive all email messages.
                for (int number = 1; number <= count && number<200; count--)
                {
                    GemBox.Email.MailMessage message = pop.GetMessage(count.Value);

                    // Read and display email's date and subject.
                    richTextBox1.Text += ($"  {number}  |  {message.Date.ToShortDateString()}  |  {message.Subject}")+"\n";
                }
            }
        }

        private void Inbox_Load(object sender, EventArgs e)
        {
            // If using Professional version, put your serial key below.
            ComponentInfo.SetLicense("FREE-LIMITED-KEY");

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
