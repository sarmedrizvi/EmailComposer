﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.Text.RegularExpressions;
using System.Net.Mail;
using EASendMail;
using System.Net;
using System.Net.Sockets;

namespace EmailComposer
{
    public partial class AddContact : Form
    {
        public static string connectionString = @"Data Source=DESKTOP-5HNPRO6;Initial Catalog=EmailComposer;Integrated Security=True";
        public static SqlConnection Sql = new SqlConnection(connectionString);
        public AddContact()
        {
            InitializeComponent();
        }
        Contacts contacts = new Contacts();
        public AddContact(Contacts contacts)
        {
            this.contacts = contacts;
            InitializeComponent();
        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)

        {
            if (button1.Text == "Add")
            {
            
                    if (textBox2.Text == "")
                    {
                        throw new Exception("Email should not be null");
                    }
                   
                        EmailSend.IsEmail(textBox2.Text); if (textBox8.Text != string.Empty) { EmailSend.IsEmail(textBox8.Text); }

                        if (Sql.State == ConnectionState.Closed)
                        {
                            Sql.Open();
                        }
                        //string c = "select  top 1 Id  from contacts order by  Id desc";
                        //SqlCommand sqlCommand1 = new SqlCommand(c, Sql);
                        //SqlDataAdapter sqlData = new SqlDataAdapter(); DataTable dataTable = new DataTable();
                        //sqlData.SelectCommand = sqlCommand1; sqlData.Fill(dataTable);
                        //int id = 1;
                        //if (dataTable.Rows.Count != 0)
                        //{ id = Convert.ToInt32(dataTable.Rows[0][0].ToString()) + 1; }
                        string command = $"insert into contacts values('{textBox1.Text.ToLower()}','{textBox4.Text}','{textBox7.Text}','{textBox2.Text.ToLower()}','{textBox8.Text.ToLower()}','{textBox3.Text}|{textBox9.Text}','{comboBox1.Text}','{textBox5.Text.ToLower()}','{textBox6.Text}')";
                        SqlCommand sqlCommand = new SqlCommand(command, Sql);
                        sqlCommand.ExecuteNonQuery();
                        MessageBox.Show("Contact has been added");
                        contacts.RefreshContacts();
                    

            }
          
                if (button1.Text == "Update")
                {
                    if (textBox2.Text == "")
                    {
                        throw new Exception("Email should not be null");
                    }
                    EmailSend.IsEmail(textBox2.Text); if (textBox8.Text != "") { EmailSend.IsEmail(textBox8.Text); }
                    string command2 = $"update contacts set CompanyName= '{textBox1.Text}',EmployeeName='{textBox4.Text}',EmployeeDesignation='{textBox7.Text}'" +
                     $",Email ='{textBox2.Text}',SecondEmail='{textBox8.Text}',PhoneNumber='{textBox3.Text}|{textBox9.Text}',Region='{comboBox1.Text}'," +
                     $"Country='{textBox5.Text}',City='{textBox6.Text}' where Id='{contacts.dataGridView1.SelectedRows[0].Cells[0].Value}'";
                    SqlCommand sql = new SqlCommand(command2, AddContact.Sql);
                    sql.ExecuteNonQuery();
                    MessageBox.Show("Selected Contact Updated");
                    this.Close();
                    contacts.RefreshContacts();
                }
            

        }

        private void AddContact_Load(object sender, EventArgs e)
        {

        }
       

    }
}
