﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EmailComposer
{
    public partial class userItems : UserControl
    {
        public userItems()
        {
            InitializeComponent();
        }
        public string To { get { return to.Text; } set { to.Text = value; } }
        public string From { get { return from.Text; } set { from.Text = value; } }
        public string Subject { get { return subject.Text; } set { subject.Text = value; } }
        public string Date { get {return date.Text; } set { date.Text = value; } }
        public string Body { get { return richTextBox1.Text; } set { richTextBox1.Text = value; } }
        public string Id { get { return id.Text; } set { id.Text = value; } }
        private void userItems_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        { string message = " Do you want to delete Mail?";
            string caption = "Delete Mail";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;
            result = MessageBox.Show(message, caption, buttons, MessageBoxIcon.Information);

            if (result == DialogResult.Yes)
            {
                this.Visible = false;
                string com = $"delete from sentItems where Id={Id}";
                SqlCommand sql = new SqlCommand(com, AddContact.Sql);
                sql.ExecuteNonQuery();
            }

        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
