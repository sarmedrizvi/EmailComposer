﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmailComposer

{
    public delegate void ButtonHover1(object sender, EventArgs e);
   
    public delegate void ButtonLeave1(object sender, EventArgs e);
   
    public delegate void Click1(object sender, EventArgs e);
    public partial class Top : UserControl
    {
        public Image ICON { get { return pictureBox1.Image; } set { pictureBox1.Image = value; } }
      
        public event Click1 ClickLabel1;
        public event Click1 ClickLabel2;
        public event Click1 ClickLabel4;
        public event Click1 ClickLabel5;
        public event Click1 ClickLabel6;
        public event Click1 ClickLabel3;
        public event Click1 ClickLabel9;
        public event Click1 ClickLabel8;
        public event Click1 ClickLabel7;public event Click1 clickaddmaterial; public event Click1 clickupdatematerial; public event Click1 clickdeletematerial;
        public event Click1 materialClick; public event Click1 jobWorkClick; public event Click1 maintananaceClick; public event Click1 saleClick;
        public event Click1 homeClick; public event Click1 other; public event Click1 dashboard;
        public event ButtonHover1 ButtonHover1;
        public event ButtonHover1 ButtonHover8;
        public event ButtonHover1 ButtonHover3;
        public event ButtonHover1 ButtonHover4;
        public event ButtonHover1 ButtonHover5;
      
        public event ButtonLeave1 ButtonLeave3;
        public event ButtonLeave1 ButtonLeave4;
        public event ButtonLeave1 ButtonLeave5;
        ToolTip t = new ToolTip();
        int s = 115;
        bool hided = false;
        bool hided2 = false;
        int size = 208;
        public Top()
        {
            
           
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label1_MouseLeave(object sender, EventArgs e)
        {

            

        }

        private void label2_MouseHover(object sender, EventArgs e)
        {
           
          
        }

        private void label2_MouseLeave(object sender, EventArgs e)
        {
            
                  }

      

        private void label5_MouseHover(object sender, EventArgs e)
        {
            if (ButtonHover4 != null)
                ButtonHover4(sender, e);
            label5.Size = new Size(153, 30);
            pictureBox5.Size = new Size(40, 35);
            t.SetToolTip(label5, "CricketBoards List");
          

        }

        private void label5_MouseLeave(object sender, EventArgs e)
        {
            if (ButtonLeave4 != null)
                ButtonLeave4(sender, e);
            label5.Size = new Size(153, 20);
            pictureBox5.Size = new Size(35, 29);
          
        }

        private void label6_MouseHover(object sender, EventArgs e)
        {
            if (ButtonHover5 != null)
                ButtonHover5(sender, e);
            label6.Size = new Size(177, 30);
            pictureBox6.Size = new Size(40, 35);
            t.SetToolTip(label6, "CricketLeague List");
          
        }

        private void label6_MouseLeave(object sender, EventArgs e)
        {
            if (ButtonLeave5 != null)
                ButtonLeave5(sender, e);
            label6.Size = new Size(177, 20);
            pictureBox6.Size = new Size(35, 29);
          

        }
        
        private void label1_Click_1(object sender, EventArgs e)
        {
            if (ClickLabel1 != null)
                ClickLabel1(sender, e);

        }

        private void label2_Click_1(object sender, EventArgs e)
        {
            if (ClickLabel2 != null)
                ClickLabel2(sender, e);

        }

        private void label4_Click_1(object sender, EventArgs e)
        {
            if (ClickLabel4 != null)
                ClickLabel4(sender, e);

        }

        private void label5_Click_1(object sender, EventArgs e)
        {
            if (ClickLabel5 != null)
                ClickLabel5(sender, e);
        }

        private void label6_Click_1(object sender, EventArgs e)
        {
            if (ClickLabel6 != null)
                ClickLabel6(sender, e);

        }

        private void label3_Click_1(object sender, EventArgs e)
        {
            if (ClickLabel3 != null)
                ClickLabel3(sender, e);
        }

        private void label9_Click(object sender, EventArgs e)
        {
            if (ClickLabel9 != null)
                ClickLabel9(sender, e);
        }

        private void label8_Click(object sender, EventArgs e)
        {
            if (ClickLabel8 != null)
                ClickLabel8(sender, e);
        }

        private void label7_Click(object sender, EventArgs e)
        {
            if (ClickLabel7 != null)
                ClickLabel7(sender, e);
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Update_Click(object sender, EventArgs e)
        {
            material.Start();
            if (clickupdatematerial != null)
            {
                clickupdatematerial(sender, e);

            }
        }

        private void label1_MouseHover_1(object sender, EventArgs e)
        {
            if (ButtonHover1 != null)
                ButtonHover1(sender, e);
            label1.Size = new Size(57, 30);
            pictureBox2.Size = new Size(40, 35);
            t.SetToolTip(label1, "Material");

            material.Start();
        }

        private void material_Tick(object sender, EventArgs e)
        {if (hided == true)
            {
                panel2.Width = panel2.Width + 10;
                if (panel2.Width >= s)
                {
                    material.Stop();
                    hided = false;
                }
            }
        else
            {
                panel2.Width = panel2.Width - 10;
                if (panel2.Width <= 0)
                {
                    material.Stop();
                    hided = true;
                }

            }
          

        }

        private void Add_Click(object sender, EventArgs e)
        {
            material.Start();
            if(clickaddmaterial!=null)
            {
                clickaddmaterial(sender, e);

            }
        }

        private void Delete_Click(object sender, EventArgs e)
        {
            material.Start();
            if (clickdeletematerial != null)
            {
                clickdeletematerial(sender, e);

            }
        }

        private void Reports_Tick(object sender, EventArgs e)
        {
            if (hided2 == true)
            {
                panel3.Width = panel3.Width + 10;
                if (panel3.Width >= size)
                {
                    Reports.Stop();
                    hided2 = false;
                }
            }
            else
            {
                panel3.Width = panel3.Width - 10;
                if (panel3.Width <= 0)
                {
                    Reports.Stop();
                    hided2 = true;
                }

            }
        }

        private void label8_MouseHover(object sender, EventArgs e)
        {
            if(ButtonHover8!=null)
            {
                ButtonHover8(sender, e);
            }
            Reports.Start();
        }

        private void label10_Click(object sender, EventArgs e)
        {
            Reports.Start();
            if (materialClick!=null)
            {
                materialClick(sender, e);
            }
        }

        private void label9_Click_1(object sender, EventArgs e)
        {
            Reports.Start();
            if (jobWorkClick != null)
            {
                jobWorkClick(sender, e);
            }
        }

        private void label2_Click(object sender, EventArgs e)
        {
            Reports.Start();
            if (maintananaceClick != null)
            {
                maintananaceClick(sender, e);
            }
        }

        private void label11_Click(object sender, EventArgs e)
        {
            Reports.Start();
            if (saleClick != null)
            {
                saleClick(sender, e);
            }
        }

        private void label12_Click(object sender, EventArgs e)
        {
            Reports.Start();
            if (homeClick != null)
            {
                homeClick(sender, e);
            }
        }

        private void Other_Click(object sender, EventArgs e)
        {
            Reports.Start();
            if (other != null)
            {
                other(sender, e);
            }
        }

        private void label13_Click(object sender, EventArgs e)
        {
            if (dashboard != null)
                dashboard(sender, e);
        }

        private void Top_Load(object sender, EventArgs e)
        {
            this.Dock = DockStyle.Top;
        }
    }
}
