﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using System.IO;
using Microsoft.SqlServer;

using GemBox.Spreadsheet;
using GemBox.Spreadsheet.WinFormsUtilities;
using Microsoft.SqlServer.Management.Smo;
using Microsoft.SqlServer.Management.Common;

namespace EmailComposer
{
    public partial class Form1 : Form
    {
        
        public Form1()
        {
            InitializeComponent();
            SpreadsheetInfo.SetLicense("FREE-LIMITED-KEY");

        }
        

        private void Form1_Load(object sender, EventArgs e)
        {
            string c = "SELECT COUNT(Id)FROM sentItems ";
            SqlCommand sqlCommand = new SqlCommand(c, AddContact.Sql);
            object result = sqlCommand.ExecuteScalar();
            label3.Text="Total SentItems: "+Convert.ToString(result);
            string command = "select * from sentItems";
            SqlCommand sql = new SqlCommand(command, AddContact.Sql);
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(); DataTable data = new DataTable();
            sqlDataAdapter.SelectCommand = sql;
            sqlDataAdapter.Fill(data);
            if (data.Rows.Count != 0)
            {
                for (int i = 0; i < data.Rows.Count; i++)
                {
                    userItems userItems = new userItems();
                    this.userItems.Controls.Add(userItems);
                    userItems.Dock = DockStyle.Top;
                    userItems.To = "To:" + data.Rows[i][1].ToString();
                    userItems.From = "From:" + data.Rows[i][2].ToString();

                    userItems.Subject = "Subject:" + data.Rows[i][3].ToString();
                    userItems.Date = data.Rows[i][5].ToString();
                    userItems.Body = data.Rows[i][4].ToString();
                    userItems.Id = data.Rows[i][0].ToString();
                    if (data.Rows[i][3].ToString() == "")
                    {
                        userItems.Subject = "(Nosubject)";
                    }
                    if (userItems.Body == "")
                    {
                        userItems.Size = new Size(1012, 86);
                    }

                }

            }

        }


        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void country_Tick(object sender, EventArgs e)
        {
            //if (hided == true)
            //{
            //    panel2.Width = panel2.Width + 10;
            //    if (panel2.Width >= size)
            //    {
            //        country.Stop();
            //        hided = false;
            //    }
            //}
            //else
            //{
            //    panel2.Width = panel2.Width - 10;
            //    if (panel2.Width <= 0)
            //    {
            //        country.Stop();
            //        hided = true;
            //    }

            //}
        }

        private void label13_MouseHover(object sender, EventArgs e)
        {
            country.Start();
        }

        private void pictureBox3_Click(object sender, EventArgs e)
        {
            message1.BringToFront();
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
            contacts1.BringToFront();
            contacts1.RefreshContacts();
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            string message = "Do you want to logout?";
            string caption = "LOGOUT";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;
            result = MessageBox.Show(message, caption, buttons, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                Login login = new Login();
                login.Show();
                this.Hide();
            }
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {
            string message = "Do you want to backup?";
            string caption = "Backup";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;
            result = MessageBox.Show(message, caption, buttons, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                if (AddContact.Sql.State == ConnectionState.Closed)
                {
                    AddContact.Sql.Open();
                }
                try
                {
                    if (!Directory.Exists(@"C:\SqlBackup"))
                    { Directory.CreateDirectory(@"C:\SqlBackup"); }
                    string str = "USE EmailComposer;";
                    string str1 = @"BACKUP DATABASE EmailComposer TO DISK = 'C:SqlBackup\EmailComposer.BAK' WITH FORMAT,MEDIANAME = 'Z_SQLServerBackups',NAME = 'Full Backup of EmailContacts';";
                    SqlCommand cmd1 = new SqlCommand(str, AddContact.Sql);
                    SqlCommand cmd2 = new SqlCommand(str1, AddContact.Sql);
                    cmd1.ExecuteNonQuery();
                    cmd2.ExecuteNonQuery();
                    MessageBox.Show("Backup completed");
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }
            }
        }

        private void pictureBox6_Click(object sender, EventArgs e)
        {
            var saveFileDialog = new SaveFileDialog();
            saveFileDialog.Filter = "XLS files (*.xls)|*.xls|XLT files (*.xlt)|*.xlt|XLSX files (*.xlsx)|*.xlsx|XLSM files (*.xlsm)|*.xlsm|XLTX (*.xltx)|*.xltx|XLTM (*.xltm)|*.xltm|ODS (*.ods)|*.ods|OTS (*.ots)|*.ots|CSV (*.csv)|*.csv|TSV (*.tsv)|*.tsv|HTML (*.html)|*.html|MHTML (.mhtml)|*.mhtml|PDF (*.pdf)|*.pdf|XPS (*.xps)|*.xps|BMP (*.bmp)|*.bmp|GIF (*.gif)|*.gif|JPEG (*.jpg)|*.jpg|PNG (*.png)|*.png|TIFF (*.tif)|*.tif|WMP (*.wdp)|*.wdp";
            saveFileDialog.FilterIndex = 3;

            if (saveFileDialog.ShowDialog() == DialogResult.OK)
            {
                var workbook = new ExcelFile();
                var worksheet = workbook.Worksheets.Add("Sheet1");

                // From DataGridView to ExcelFile.
                DataGridViewConverter.ImportFromDataGridView(worksheet,contacts1.dataGridView1, new ImportFromDataGridViewOptions() { ColumnHeaders = true });

                workbook.Save(saveFileDialog.FileName);
            }
       }

        private void pictureBox5_MouseHover(object sender, EventArgs e)
        {
            ToolTip t = new ToolTip();
            t.SetToolTip(pictureBox5, "Backup at C: disk");
        }

        private void pictureBox4_MouseHover(object sender, EventArgs e)
        {
            ToolTip t = new ToolTip();
            t.SetToolTip(pictureBox4, "Logout");
        }

        private void pictureBox6_MouseHover(object sender, EventArgs e)
        {
            ToolTip t = new ToolTip();
            t.SetToolTip(pictureBox6, "Contact Copy");

        }

        private void label2_Click(object sender, EventArgs e)
        {
            userItems.Controls.Clear();
            string c = "SELECT COUNT(Id)FROM sentItems ";
            SqlCommand sqlCommand = new SqlCommand(c, AddContact.Sql);
            object result = sqlCommand.ExecuteScalar();
            label3.Text = "Total SentItems: " + Convert.ToString(result);
            string command = "select * from sentItems";
            SqlCommand sql = new SqlCommand(command, AddContact.Sql);
            SqlDataAdapter sqlDataAdapter = new SqlDataAdapter(); DataTable data = new DataTable();
            sqlDataAdapter.SelectCommand = sql;
            sqlDataAdapter.Fill(data);
            if (data.Rows.Count != 0)
            {
                for (int i = 0; i < data.Rows.Count; i++)
                {
                    userItems userItems = new userItems();
                    this.userItems.Controls.Add(userItems);
                    userItems.Dock = DockStyle.Top;
                    userItems.To = "To:" + data.Rows[i][1].ToString();
                    userItems.From = "From:" + data.Rows[i][2].ToString();

                    userItems.Subject = "Subject:" + data.Rows[i][3].ToString();
                    userItems.Date = data.Rows[i][5].ToString();
                    userItems.Body = data.Rows[i][4].ToString();
                    userItems.Id = data.Rows[i][0].ToString();
                    if (data.Rows[i][3].ToString() == "")
                    {
                        userItems.Subject = "(Nosubject)";
                    }
                    if (userItems.Body == "")
                    {
                        userItems.Size = new Size(1012, 86);
                    }

                }

            }
            userItems.BringToFront();
            
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void message1_Load(object sender, EventArgs e)
        {

        }

        private void inbox1_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox7_MouseHover(object sender, EventArgs e)
        {
            ToolTip t = new ToolTip();
            t.SetToolTip(pictureBox7, "Restore");

        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            using (OpenFileDialog openFile = new OpenFileDialog())
            {
                openFile.Filter = "SqlBackup|*.bak";
                openFile.FileName = "Restore";
                if ( openFile.ShowDialog()==DialogResult.OK)
                {
                    Restore(openFile.FileName);
                }
            }

        }
        public void Restore(string Filepath)
        {
            try
            {
                if (AddContact.Sql.State == ConnectionState.Closed)
                {
                    AddContact.Sql.Open();
                }
                SqlCommand cmd1 = new SqlCommand("ALTER DATABASE [" + "EmailComposer" + "] SET SINGLE_USER WITH ROLLBACK IMMEDIATE ", AddContact.Sql);
                cmd1.ExecuteNonQuery();
                SqlCommand cmd2 = new SqlCommand("USE MASTER RESTORE DATABASE [" + "EmailComposer" + "] FROM DISK='" + Filepath + "' WITH REPLACE", AddContact.Sql);
                cmd2.ExecuteNonQuery();
                SqlCommand cmd3 = new SqlCommand("ALTER DATABASE [" + "EmailComposer" + "] SET MULTI_USER", AddContact.Sql);
                cmd3.ExecuteNonQuery();
                AddContact.Sql.Close();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            AddContact.Sql.Close();
        }

        private void pictureBox8_MouseHover(object sender, EventArgs e)
        {
            ToolTip t = new ToolTip();
            t.SetToolTip(pictureBox7, "users"); 
        }

        private void pictureBox8_Click(object sender, EventArgs e)
        {
            userform userform = new userform();
            userform.Show();
        }
    }
}
