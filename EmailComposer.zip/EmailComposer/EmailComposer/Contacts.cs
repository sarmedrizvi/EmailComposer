﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;
using GemBox.Spreadsheet;

namespace EmailComposer
{
    public partial class Contacts : UserControl
    {
        public Contacts()
        {
            InitializeComponent();
            SpreadsheetInfo.SetLicense("FREE-LIMITED-KEY");
        }

        private void button7_Click(object sender, EventArgs e)
        {
            AddContact addContact = new AddContact(this);
            addContact.ShowDialog();

        }
       


        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        public void RefreshContacts()
        {
            if (AddContact.Sql.State == ConnectionState.Closed)
            {
                AddContact.Sql.Open();
            }
            string command = $"select * from contacts";
            SqlCommand sqlCommand = new SqlCommand(command, AddContact.Sql);
            SqlDataAdapter dataAdapter = new SqlDataAdapter();
            DataTable table = new DataTable();
            dataAdapter.SelectCommand = sqlCommand;
            dataAdapter.Fill(table);
            dataGridView1.DataSource = table;
            sqlCommand.ExecuteNonQuery();
        }

        private void Contacts_Load(object sender, EventArgs e)
        {
            RefreshContacts();
            if(comboBox1.Text=="")
            {
                textBox2.Enabled = false;
            }

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            if(comboBox1.Text=="CompanyName")
            {
                if (AddContact.Sql.State == ConnectionState.Closed)
                {
                    AddContact.Sql.Open();
                }


                string command = $"select * from contacts where CompanyName like '{textBox2.Text}%'";
                SqlCommand sqlCommand = new SqlCommand(command, AddContact.Sql);
                SqlDataAdapter dataAdapter = new SqlDataAdapter();
                DataTable table = new DataTable();
                dataAdapter.SelectCommand = sqlCommand;
                dataAdapter.Fill(table);
                dataGridView1.DataSource = table;
                sqlCommand.ExecuteNonQuery();
            }
           else if (comboBox1.Text == "EmailAddress")
            {
                if (AddContact.Sql.State == ConnectionState.Closed)
                {
                    AddContact.Sql.Open();
                }


                string command = $"select * from contacts where Email like '{textBox2.Text}%'";
                SqlCommand sqlCommand = new SqlCommand(command, AddContact.Sql);
                SqlDataAdapter dataAdapter = new SqlDataAdapter();
                DataTable table = new DataTable();
                dataAdapter.SelectCommand = sqlCommand;
                dataAdapter.Fill(table);
                dataGridView1.DataSource = table;
                sqlCommand.ExecuteNonQuery();
            }
            else if(comboBox1.Text=="PhoneNumber")
            {
                 if (AddContact.Sql.State == ConnectionState.Closed)
                {
                    AddContact.Sql.Open();
                }


                string command = $"select * from contacts where PhoneNumber like '{textBox2.Text}%'";
                SqlCommand sqlCommand = new SqlCommand(command, AddContact.Sql);
                SqlDataAdapter dataAdapter = new SqlDataAdapter();
                DataTable table = new DataTable();
                dataAdapter.SelectCommand = sqlCommand;
                dataAdapter.Fill(table);
                dataGridView1.DataSource = table;
                sqlCommand.ExecuteNonQuery();
            }
            else if(comboBox1.Text=="Country")
            {
                if (AddContact.Sql.State == ConnectionState.Closed)
                {
                    AddContact.Sql.Open();
                }


                string command = $"select * from contacts where Country like '{textBox2.Text}%'";
                SqlCommand sqlCommand = new SqlCommand(command, AddContact.Sql);
                SqlDataAdapter dataAdapter = new SqlDataAdapter();
                DataTable table = new DataTable();
                dataAdapter.SelectCommand = sqlCommand;
                dataAdapter.Fill(table);
                dataGridView1.DataSource = table;
                sqlCommand.ExecuteNonQuery();
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {
           
            if (AddContact.Sql.State == ConnectionState.Closed)
            {
                AddContact.Sql.Open();
            }


            string command = $"select * from contacts where Id='{dataGridView1.SelectedRows[0].Cells[0].Value}'";
            SqlCommand sqlCommand = new SqlCommand(command, AddContact.Sql);
            SqlDataAdapter dataAdapter = new SqlDataAdapter();
            DataTable table = new DataTable();
            dataAdapter.SelectCommand = sqlCommand;
            dataAdapter.Fill(table);
            AddContact addContact = new AddContact(this);
            addContact.textBox1.Text = table.Rows[0][1].ToString();
            addContact.textBox4.Text = table.Rows[0][2].ToString();
            addContact.textBox7.Text = table.Rows[0][3].ToString();
            addContact.textBox2.Text = table.Rows[0][4].ToString();
            addContact.textBox8.Text = table.Rows[0][5].ToString();
            addContact.textBox3.Text = GetEmail(table.Rows[0][6].ToString()).Item1;
            addContact.textBox9.Text = GetEmail(table.Rows[0][6].ToString()).Item2;
            addContact.comboBox1.Text = table.Rows[0][7].ToString();
            addContact.textBox5.Text = table.Rows[0][8].ToString();
            addContact.textBox6.Text = table.Rows[0][9].ToString();
            addContact.button1.Text = "Update";
            addContact.ShowDialog();
            sqlCommand.ExecuteNonQuery();
           

           
        }
        public static Tuple<string,string> GetEmail( string email)
        {
            string[] a = email.Split('|');
            return new Tuple<string, string>(a[0], a[1]);

        }

        private void pictureBox2_Click(object sender, EventArgs e)
        {
            string message = "Are you sure you want to delete this contact?";
            string caption = "Delete Contact";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;
            result = MessageBox.Show(message, caption, buttons, MessageBoxIcon.Error);

            if (result == DialogResult.Yes)
            {
                string command = $"delete from contacts where Id='{dataGridView1.SelectedRows[0].Cells[0].Value}'";
                SqlCommand sqlCommand = new SqlCommand(command, AddContact.Sql);
                SqlDataAdapter dataAdapter = new SqlDataAdapter();
                DataTable table = new DataTable();
                dataAdapter.SelectCommand = sqlCommand;
                dataAdapter.Fill(table);
                sqlCommand.ExecuteNonQuery();
                RefreshContacts();
            }
           
        }

        private void comboBox1_DropDownClosed(object sender, EventArgs e)
        {
            if (comboBox1.Text != "")
            {
                textBox2.Enabled = true;
            }
            else
                textBox2.Enabled = false;
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
    }
}
