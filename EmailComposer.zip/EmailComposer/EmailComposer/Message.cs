﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Net.Mail;
using System.Net;
using System.Data.SqlClient;
using System.Net.Mime;

namespace EmailComposer
{
    public partial class Message : UserControl
    {
        List<string> message = new List<string>();
        List<Attachment> att = new List<Attachment>();
        public Message()
        {
            
            InitializeComponent();
            if (AddContact.Sql.State == ConnectionState.Closed)
            {
                AddContact.Sql.Open();
            }

        }
        public static double percentt = 0;
        private void button2_Click(object sender, EventArgs e)
        {
           
            message.Clear();
            string[] Text1, Text2;
            Text1 = textBox1.Text.Split(',');
            Text2 = textBox3.Text.Split(',');
            string excluding = "''";
            for (int i = 0; i < Text2.Length; i++)
            {
                if (Text2[i] != string.Empty)
                {
                    excluding = string.Empty;
                    excluding += i == Text2.Length - 1 ? $"'{Text2[i]}'" : $"'{Text2[i]}',";
                }
            }
            
            if (comboBox2.Text == "Email")
            {
                for (int i = 0; i < Text1.Length; i++)
                {
                    if (Text1[i] != string.Empty)
                    {
                        message.Add(Text1[i].ToLower());
                    }
                    
                }
              
            }

            else if (comboBox2.Text == "Country")
            {
                for (int j = 0; j < Text1.Length; j++)
                {
                   
                    string command = $"select * from contacts where Country='{Text1[j].ToLower()}' and Not CompanyName in ({excluding}) and (Not Email in ({excluding}) or Not SecondEmail in ({excluding}))";
                    SqlCommand sqlCommand = new SqlCommand(command, AddContact.Sql);
                    SqlDataAdapter dataAdapter = new SqlDataAdapter();
                    DataTable table = new DataTable();
                    dataAdapter.SelectCommand = sqlCommand;
                    dataAdapter.Fill(table);
                    sqlCommand.ExecuteNonQuery();
                    if (table.Rows.Count == 0)
                    {
                        MessageBox.Show($"No such {Text1[j]} in your contacts");
                       
                    }
                    else
                    {
                        for (int i = 0; i < table.Rows.Count; i++)
                        {
                            string email1 = table.Rows[i][4].ToString();
                            string email2 = table.Rows[i][5].ToString();
                            string companyName = table.Rows[i][1].ToString();
                                    message.Add(email1);
                            if (email2 != string.Empty) { message.Add(email2); }
                        }

                    }

                 
                }
              

            }

            else if (comboBox2.Text == "Company Name")
            {
                for (int j = 0; j < Text1.Length; j++)
                {
                    string command = $"select * from contacts where CompanyName='{Text1[j].ToLower()}' and Not Email in ({excluding}) or Not SecondEmail in ({excluding})";
                    SqlCommand sqlCommand = new SqlCommand(command, AddContact.Sql);
                    SqlDataAdapter dataAdapter = new SqlDataAdapter();
                    DataTable table = new DataTable();
                    dataAdapter.SelectCommand = sqlCommand;
                    dataAdapter.Fill(table);
                    sqlCommand.ExecuteNonQuery();
                    if (table.Rows.Count == 0)
                    {
                      
                        MessageBox.Show($"No such {Text1[j]} in your contacts");

                    }
                    else
                    {
                        for (int i = 0; i < table.Rows.Count; i++)
                        {
                            string companyName = table.Rows[i][1].ToString().ToLower();
                            string Email = table.Rows[i][4].ToString();
                            string Email2 = table.Rows[i][5].ToString();
                            message.Add(Email);
                            if (Email2 != string.Empty) { message.Add(Email2); }
                               
                        }

                    }
                    
                }

            }
            else
            {
               
                MessageBox.Show("Something is wrong ");
                return;
            }

            for (int i = 0; i < message.Count; i++)
            {
               
                EmailSend.Send(textBox2.Text, message[i], richTextBox1.Text, att);
                string c = "select  Top 1 id  from sentItems  order by  id desc";
                SqlCommand sqlCommand1 = new SqlCommand(c, AddContact.Sql);
                SqlDataAdapter sqlData = new SqlDataAdapter(); DataTable dataTable = new DataTable();
                sqlData.SelectCommand = sqlCommand1; sqlData.Fill(dataTable);
                int id = 1;
                if (dataTable.Rows.Count != 0)
                { id = Convert.ToInt32(dataTable.Rows[0][0].ToString()) + 1; }
                string com = $"insert into sentItems values('{id}','{message[i]}','{EmailSend.UserName}','{textBox2.Text.ToString()}','{richTextBox1.Text}','{DateTime.Now}')";
                SqlCommand sqlCommand2 = new SqlCommand(com, AddContact.Sql);
                sqlCommand2.ExecuteNonQuery();
                // Report progress to 'UI' thread
              //  messageSent.Text = (Convert.ToInt32(i.ToString()) + 1).ToString() + "/n send";

            }
            if (message.Count != 0)
            {
                MessageBox.Show("Email has been sent");
                
            }

        }

        private void BackgroundWorker1_DoWork(object sender, DoWorkEventArgs e)
        {
           

        }

        List<string> labelFileName = new List<string>();
        List<string> labelSafeFileName = new List<string>();
        Label picture;
     
        private void button3_Click(object sender, EventArgs e)
        {

            OpenFileDialog c = new OpenFileDialog();
            c.Filter = "All Files|*.*|JPEG|*.jpg|PNG|*.png|PDF|*.pdf|Textfile|.txt|PowerPoint|.pptx|Word|.docx";
                c.Title = "Attachments";
                if (c.ShowDialog()==DialogResult.OK)
                {// Add time stamp information for the file.
                    
                    EmailSend.disposition.CreationDate = System.IO.File.GetCreationTime(c.FileName);
                    EmailSend.disposition.ModificationDate = System.IO.File.GetLastWriteTime(c.FileName);
                    EmailSend.disposition.ReadDate = System.IO.File.GetLastAccessTime(c.FileName);
                    att.Add(new Attachment(c.FileName,MediaTypeNames.Application.Octet));
                    picture = new Label();
                    panel1.Controls.Add(picture);
                    picture.Dock = DockStyle.Left;
                    picture.AutoSize = false;
                    picture.BorderStyle = BorderStyle.FixedSingle;
                    picture.BackColor = Color.PeachPuff;
                    picture.Text = c.SafeFileName;
                    picture.Tag = c.FileName;
                    picture.Font = new Font("Rockwell", 11.25F,FontStyle.Bold,GraphicsUnit.Point, ((byte)(0)));
                   ToolTip t = new ToolTip();
                   t.SetToolTip(picture, c.SafeFileName);
              
                }
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void Message_Load(object sender, EventArgs e)
        {
            if(comboBox2.Text=="")
            {
                textBox1.Enabled = false;
            }
        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {   string message = "Do you want to clear?";
            string caption = "Clear All";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;
            result = MessageBox.Show(message, caption, buttons, MessageBoxIcon.Exclamation);

            if (result == DialogResult.Yes)
            {
                panel1.Controls.Clear();
                richTextBox1.Clear();
                textBox1.Text = "Recipents";
                textBox2.Clear();
              
                textBox3.Text = "Email";
                att.Clear();
            }
        }

        private void comboBox2_DropDownClosed(object sender, EventArgs e)
        {
            if (comboBox2.Text != "")
            {
                textBox1.Enabled = true;
            }
            else
                textBox1.Enabled = false;
        }

        private void button3_MouseHover(object sender, EventArgs e)
        {
            ToolTip t = new ToolTip();
            t.SetToolTip(button3, "Attachments");
        }

        private void pictureBox1_MouseLeave(object sender, EventArgs e)
        {

        }

        private void pictureBox1_MouseHover(object sender, EventArgs e)
        {
            ToolTip t = new ToolTip();
            t.SetToolTip(pictureBox1, "Clear All");
        }

        private void button2_MouseHover(object sender, EventArgs e)
        {
            ToolTip t = new ToolTip();
            t.SetToolTip(button2, "Send Email");
        }

        private void panel2_Paint(object sender, PaintEventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void comboBox2_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (comboBox2.Text==string.Empty)
            {
                textBox3.Enabled = false;
                textBox1.Enabled = false;
            }
            else
            {
                textBox1.Enabled = true;
                textBox3.Enabled = true;
            }
            if(comboBox2.Text=="Email")
            {
                textBox3.Enabled = false;
                textBox3.Text = "";
            }
            else
            {
                textBox3.Enabled = true;
            }
            if(comboBox2.Text=="Company Name")
            {
                textBox3.Text = "Email";
            }
            if (comboBox2.Text == "Country")
            {
                textBox3.Text = "Company Name,Email";
            }

        }

        private void progressBar1_Click(object sender, EventArgs e)
        {

        }

        private void timer1_Tick(object sender, EventArgs e)
        {
         

        }

        private void backgroundWorker1_DoWork_1(object sender, DoWorkEventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
           
        }

        private void richTextBox1_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
