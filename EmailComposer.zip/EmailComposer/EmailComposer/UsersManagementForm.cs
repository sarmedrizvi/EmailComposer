﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EmailComposer
{
    public partial class UsersManagementForm : UserControl
    {
        public UsersManagementForm()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (button1.Text == "Update")
            {

                password.Enabled = false;
                button1.Text = "Edit";
                if (AddContact.Sql.State == ConnectionState.Closed)
                {
                    AddContact.Sql.Open();
                }
                string command = $"update Users set Password='{password.Text}' where Username='{username.Text}'";
                SqlCommand sqlCommand = new SqlCommand(command, AddContact.Sql);
                sqlCommand.ExecuteNonQuery();
                return;

            }
            if (button1.Text=="Edit")
            {
                button1.Text = "Update";
                password.Enabled = true;
            }
          
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (AddContact.Sql.State == ConnectionState.Closed)
            {
                AddContact.Sql.Open();
            }
            string command = $"delete from Users where Username='{username.Text}'";
            SqlCommand sqlCommand = new SqlCommand(command, AddContact.Sql);
            sqlCommand.ExecuteNonQuery();
            this.Visible = false;
        }

        private void username_MouseLeave(object sender, EventArgs e)
        {
            ToolTip toolTip = new ToolTip();
            toolTip.SetToolTip(username, username.Text);
        }

        private void password_MouseHover(object sender, EventArgs e)
        {
            ToolTip toolTip = new ToolTip();
            toolTip.SetToolTip(password, password.Text);
        }
    }
}
