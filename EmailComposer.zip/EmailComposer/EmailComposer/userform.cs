﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Data.SqlClient;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace EmailComposer
{
    public partial class userform : Form
    {
        public userform()
        {
            InitializeComponent();
        }
        UsersManagementForm users;

        private void userform_Load(object sender, EventArgs e)
        {
            if (AddContact.Sql.State == ConnectionState.Closed)
            {
                AddContact.Sql.Open();
            }
            string command = $"select * from Users";
            SqlCommand sqlCommand = new SqlCommand(command, AddContact.Sql);
            sqlCommand.ExecuteNonQuery();
            SqlDataAdapter dataAdapter = new SqlDataAdapter();
            DataTable table = new DataTable();
            dataAdapter.SelectCommand = sqlCommand;
            dataAdapter.Fill(table);
            if(table.Rows.Count!=0)
            {
                for (int i = 0; i < table.Rows.Count; i++)
                {
                    users = new UsersManagementForm();
                    users.username.Text = table.Rows[i][0].ToString();
                    users.password.Text = table.Rows[i][1].ToString();
                    users.Dock = DockStyle.Top;
                    Controls.Add(users);

                }

            }
           


        }
    }
}
