﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Net;
using System.Net.Mail;
using System.Windows.Forms;
using System.Net.Mime;

namespace EmailComposer
{
    class EmailSend
    {
        string subject;
        string receiverEmail;
        string body;
        Message message;
        public EmailSend(Message message)
        {
            this.message = message;
            subject = "";
            receiverEmail = "";
            body = "";
        }
        public EmailSend(string subject, string receiverEmail, string body)
        {
            this.subject = subject;
            this.receiverEmail = receiverEmail;
            this.body = body;
        }
        public static ContentDisposition disposition = new ContentDisposition();
        public string Subject { get { return subject; } set { subject = value; } }
        public string ReceiverEmail { get { return receiverEmail; } set { receiverEmail = value; } }
        public string Body { get { return body; } set { body = value; } }
        public static void Send(string subject, string receiverEmail, string body, List<Attachment> attachments)
        {
            MailMessage mail = new MailMessage();
            SmtpClient smtpClient = new SmtpClient("smtp.gmail.com");
            smtpClient.Port = 587;
            smtpClient.EnableSsl = true;
            smtpClient.UseDefaultCredentials = false;
            smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtpClient.Credentials = new NetworkCredential(userName, password);
            mail.From = new MailAddress(userName);
            mail.To.Add(receiverEmail);
            mail.Subject = subject;
            mail.Body = body;

            for (int i = 0; i < attachments.Count; i++)
            {
                disposition = attachments[i].ContentDisposition;
                mail.Attachments.Add(attachments[i]);
            }
            smtpClient.Send(mail);
            smtpClient.SendCompleted += SmtpClient_SendCompleted1;
            smtpClient.SendCompleted += new SendCompletedEventHandler(SmtpClient_SendCompleted1);
         

        }

        private static void SmtpClient_SendCompleted1(object sender, System.ComponentModel.AsyncCompletedEventArgs e)
        {
           // Message.percent.Text = $"{Message.percentt.ToString()}%";
        }

       

        public static void Send(string subject, string receiverEmail, string body)
        {
            MailMessage mail = new MailMessage();
            SmtpClient smtpClient = new SmtpClient("smtp.gmail.com");
            smtpClient.Port = 587;
            smtpClient.EnableSsl = true;
            smtpClient.UseDefaultCredentials = false;
            smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
            smtpClient.Credentials = new NetworkCredential(userName, password);
            mail.From = new MailAddress(userName);
            mail.To.Add(receiverEmail);
            mail.Subject = subject;
            mail.Body = body;
            smtpClient.Send(mail);


        }
        //public static void isEmail(string inputEmail)
        //{

        //    if(inputEmail.Contains('@')==false)
        //    {
        //        throw new Exception("Invalid Email");
        //    }

        //}

        public static void IsEmail(string emailaddress)
        {
            try
            {
                MailAddress m = new MailAddress(emailaddress);

            }
            catch (FormatException)
            {
                MessageBox.Show("Invalid Email");
                return;
            }
        }
        static string userName;
        static string password;
        public static string UserName { get { return userName; } set { userName = value; } }
        public static string Password { get{ return password; } set { password = value; } }
        public static void Login(string username,string Password)
        {
            try
            {
                MailMessage mail = new MailMessage();
                SmtpClient smtpClient = new SmtpClient("smtp.gmail.com");
                smtpClient.Port = 587;
                smtpClient.EnableSsl = true;
                smtpClient.UseDefaultCredentials = false;
                smtpClient.DeliveryMethod = SmtpDeliveryMethod.Network;
                smtpClient.Credentials = new NetworkCredential(username, Password);
                mail.From = new MailAddress(username);
                mail.To.Add("sarmed@gmail.com");
                mail.Subject = "";
                mail.Body = "";
                smtpClient.Send(mail);
                userName = username;
                password = Password;

            }
            catch (FormatException)
            {
                
                throw new Exception("Not logined");
               
            }
        }
    }
}
