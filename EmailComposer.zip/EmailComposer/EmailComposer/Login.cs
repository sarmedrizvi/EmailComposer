﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EmailComposer
{
    public partial class Login : Form
    {
        public Login()
        {
            InitializeComponent();
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        { string message = "Are you Sure?";
            string caption = "Exit";
            MessageBoxButtons buttons = MessageBoxButtons.YesNo;
            DialogResult result;
            result = MessageBox.Show(message, caption, buttons, MessageBoxIcon.Question);

            if (result == DialogResult.Yes)
            {
                Application.Exit();
            }
        }
        bool ismaximize = true;
        private void pictureBox6_Click(object sender, EventArgs e)
        {if (ismaximize)
            {
                MaximumSize = Screen.PrimaryScreen.WorkingArea.Size;
                WindowState = FormWindowState.Maximized;
                ismaximize = false;
            }
        else
            {
                WindowState = FormWindowState.Normal;
                ismaximize=true;
            }
        }

        private void pictureBox7_Click(object sender, EventArgs e)
        {
            WindowState = FormWindowState.Minimized;
        }

        private void pictureBox4_Click(object sender, EventArgs e)
        {
            if (AddContact.Sql.State == ConnectionState.Closed)
            {
                AddContact.Sql.Open();
            }
            string command = $"select * from Users where Username='{textBox1.Text}'";
            SqlCommand sqlCommand1 = new SqlCommand(command, AddContact.Sql);
            sqlCommand1.ExecuteNonQuery();
            SqlDataAdapter dataAdapter = new SqlDataAdapter();
            DataTable table = new DataTable();
            dataAdapter.SelectCommand = sqlCommand1;
            dataAdapter.Fill(table);
            if (table.Rows.Count != 0)
            {
                MessageBox.Show("You are already added in users");
            }
            else
            {
                try
                {
                    EmailSend.Login(textBox1.Text, textBox2.Text);
                    string message = "Do you want to save?";
                    string caption = "Save";
                    MessageBoxButtons buttons = MessageBoxButtons.YesNo;
                    DialogResult result;
                    result = MessageBox.Show(message, caption, buttons, MessageBoxIcon.Question);

                    if (result == DialogResult.Yes)
                    {
                        string com = $"insert into Users values('{textBox1.Text}','{textBox2.Text}')";
                        SqlCommand sqlCommand = new SqlCommand(com, AddContact.Sql);
                        sqlCommand.ExecuteNonQuery();
                        Form1 form1 = new Form1();
                        form1.Show();
                        this.Hide();
                    }
                    else
                    {
                        Form1 form1 = new Form1();
                        form1.Show();
                        this.Hide();
                    }
                   


                }
                catch (Exception ex)
                {
                    MessageBox.Show("Invalid");
                }
            }

        }
        bool ismove = false;

        private void panel1_MouseUp(object sender, MouseEventArgs e)
        {
            ismove = false;
        }

        private void panel1_MouseDown(object sender, MouseEventArgs e)
        {
            ismove = true;
            LastLocation = e.Location;
        }
        Point LastLocation;
        private void panel1_MouseMove(object sender, MouseEventArgs e)
        {
            if (ismove)
            {
                Location = new Point(
                 (Location.X - LastLocation.X) + e.X, (Location.Y - LastLocation.Y) + e.Y);

                Update();
            }
        }
        userlisting label;

        private void Login_Load(object sender, EventArgs e)
        {
            if (AddContact.Sql.State==ConnectionState.Closed)
            {
                AddContact.Sql.Open();
            }
            string com = "select * from Users";
            SqlCommand sqlCommand = new SqlCommand(com, AddContact.Sql);
            SqlDataAdapter sqlData = new SqlDataAdapter();DataTable data = new DataTable();
            sqlCommand.ExecuteNonQuery();
            sqlData.SelectCommand = sqlCommand;
            sqlData.Fill(data);
            if (data.Rows.Count!=0)
            {
                for (int i = 0; i < data.Rows.Count; i++)
                {
                    label = new userlisting(this);
                    label.Dock = DockStyle.Top;
                    panel2.Controls.Add(label);
                    label.Cursor = Cursors.Hand;
                    label.label1.Text = $"{data.Rows[i][0].ToString()}";
                 
                }
            }
        }

        
    }
}
