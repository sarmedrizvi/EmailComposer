﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Drawing;
using System.Data;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Data.SqlClient;

namespace EmailComposer
{
    public partial class userlisting : UserControl
    {
        public userlisting()
        {
            InitializeComponent();
        }
        Login form;
        public userlisting(Login form)
        {
            this.form = form;
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {
            try
            {
                string com = $"select * from Users where Username='{label1.Text}'";
                SqlCommand sqlCommand = new SqlCommand(com, AddContact.Sql);
                SqlDataAdapter sqlData = new SqlDataAdapter(); DataTable data = new DataTable();
                sqlCommand.ExecuteNonQuery();
                sqlData.SelectCommand = sqlCommand;
                sqlData.Fill(data);
                if (data.Rows.Count != 0)
                {
                    EmailSend.Login(data.Rows[0][0].ToString(), data.Rows[0][1].ToString());
                    Form1 form1 = new Form1();
                    form1.Show();
                    form.Hide();
                    
                }
                else
                {
                    this.Visible = false;
                }
            }
            catch (Exception ex)
            {
                MessageBox.Show("Invalid");
            }
        }
    }
}
